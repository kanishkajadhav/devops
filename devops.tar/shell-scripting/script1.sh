myvar='Shell Scripting'
echo $myvar

